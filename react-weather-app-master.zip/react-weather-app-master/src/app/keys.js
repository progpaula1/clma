module.exports = {
    WEATHER_KEY: '3fc367051b4e9d0140721dfd109bf34a'
}